"""
Configuration management for Grimoire search tool.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, field

@dataclass
class GrimoireConfig:
    """Configuration settings for Grimoire."""
    
    # Search paths with default locations
    search_paths: Dict[str, Path] = field(default_factory=lambda: {
        'notes': Path(os.getenv('GRIMOIRE_NOTES_PATH', '/home/computeruse/nyra/notes/technical')),
        'resources': Path(os.getenv('GRIMOIRE_RESOURCES_PATH', '/home/computeruse/nyra/notes'))  # Changed this to notes for now
    })
    
    # Supported file types
    file_types: List[str] = field(default_factory=lambda: [
        '.txt', '.md', '.h', '.cpp', '.inl', '.as'
    ])
    
    # Search behavior settings
    max_context_lines: int = 10
    cache_results: bool = True
    cache_size: int = 100
    
    def validate(self, used_paths: List[str] = None) -> List[str]:
        """Validate configuration and return list of any errors."""
        errors = []
        
        # Check if requested search paths exist
        paths_to_check = used_paths if used_paths else self.search_paths.keys()
        for name in paths_to_check:
            if name not in self.search_paths:
                errors.append(f"Search path '{name}' is not configured")
                continue
            path = self.search_paths[name]
            if not path.exists():
                errors.append(f"Search path '{name}' does not exist: {path}")
        
        # Validate file types
        for ext in self.file_types:
            if not ext.startswith('.'):
                errors.append(f"File type must start with '.': {ext}")
        
        # Validate numeric settings
        if self.max_context_lines < 0:
            errors.append("max_context_lines must be non-negative")
        if self.cache_size < 0:
            errors.append("cache_size must be non-negative")
            
        return errors

    @classmethod
    def from_file(cls, config_path: Path) -> 'GrimoireConfig':
        """Load configuration from file."""
        # TODO: Implement config file loading
        return cls()

    def to_file(self, config_path: Path) -> None:
        """Save configuration to file."""
        # TODO: Implement config file saving
        pass