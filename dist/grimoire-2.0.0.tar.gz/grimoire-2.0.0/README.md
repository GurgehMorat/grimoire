# Grimoire

## Description
A streamlined technical documentation search tool that helps you quickly find and understand information across your knowledge base.

## Features
- Smart path matching for intuitive file location
- Context-aware search results with configurable line display
- Flexible search across multiple documentation directories
- Support for various technical file types (.md, .txt, source code)
- Clean and simple command-line interface

## Installation

### From Source (Development Mode)
```bash
# Clone the repository
git clone <repository-url> grimoire
cd grimoire

# Install in development mode
pip install -e .
```

### Using pip (once published)
```bash
pip install grimoire
```

## Quick Start
```bash
# Search in technical notes (with context)
grimoire -n "pattern"

# Search with 2 lines of context
grimoire -n -c 2 "pattern"

# Show just summary (files and match counts)
grimoire -n -s "pattern"

# Search in specific directory/file
grimoire -n -l "path/to/dir" "pattern"

# Search both notes and resources
grimoire -n -r "pattern"
```

## Configuration
Grimoire can be configured through:
- Command line arguments for quick searches
- Configuration file for persistent settings
- Environment variables for system-wide defaults

## Development
Clone the repository and install in development mode:
```bash
git clone <repository-url>
cd grimoire
pip install -e .
```