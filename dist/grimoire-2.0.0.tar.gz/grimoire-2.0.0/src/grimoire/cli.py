"""
Command-line interface for Grimoire search tool.
"""

import argparse
import sys
from pathlib import Path
from typing import List
from .config import GrimoireConfig
from .searcher import GrimoireSearcher, SearchMatch

def format_results(results: List[SearchMatch], show_context: bool = True, summary: bool = False) -> str:
    """Format search results for display."""
    if not results:
        return "No matches found."
        
    if summary:
        # Group by file path and count matches
        file_counts = {}
        for match in results:
            file_path = str(match.file_path)
            file_counts[file_path] = file_counts.get(file_path, 0) + 1
            
        # Format summary
        output = []
        output.append("\nSearch Result Summary:")
        output.append("-" * 80)
        for file_path, count in sorted(file_counts.items()):
            output.append(f"{count:3d} matches in {file_path}")
        output.append("-" * 80)
        output.append(f"Total: {len(file_counts)} files with {len(results)} matches")
        return "\n".join(output)
    
    # Detailed results format
    output = []
    for match in results:
        output.append("\n" + "=" * 80)
        output.append(f"File: {match.file_path}")
        output.append(f"Line: {match.line_number}\n")
        
        if show_context and match.context_before:
            for line in match.context_before:
                output.append(f"  | {line}")
                
        output.append(f"  > {match.line_content}")
        
        if show_context and match.context_after:
            for line in match.context_after:
                output.append(f"  | {line}")
                
    return "\n".join(output)

def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Search through technical documentation.',
        epilog='At least one search location must be specified.'
    )
    
    parser.add_argument('pattern',
                       help='Search pattern (case-insensitive)')
    parser.add_argument('-n', '--notes',
                       action='store_true',
                       help='Search in technical notes')
    parser.add_argument('-r', '--resources',
                       action='store_true',
                       help='Search in resources directory')
    parser.add_argument('-c', '--context',
                       type=int,
                       default=0,
                       help='Number of context lines to show')
    parser.add_argument('-l', '--limit',
                       type=str,
                       help='Limit search to specific file or directory')
    parser.add_argument('--no-cache',
                       action='store_true',
                       help='Disable result caching')
    parser.add_argument('-s', '--summary',
                       action='store_true',
                       help='Show only file summary with match counts')
    
    args = parser.parse_args()
    
    # Validate search locations
    if not (args.notes or args.resources):
        parser.error("At least one search location must be specified (-n for notes, -r for resources)")
    
    # Initialize configuration
    config = GrimoireConfig()
    config.cache_results = not args.no_cache
    
    # Determine search paths
    paths = []
    if args.notes:
        paths.append('notes')
    if args.resources:
        paths.append('resources')
    
    # Validate configuration for requested paths
    errors = config.validate(paths)
    if errors:
        print("Configuration errors:", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        sys.exit(1)
    
    # Initialize searcher
    searcher = GrimoireSearcher(config)
    
    # Execute search
    try:
        results = searcher.search(args.pattern, paths, args.context)
        print(format_results(results, args.context > 0, args.summary))
    except Exception as e:
        print(f"Error during search: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()