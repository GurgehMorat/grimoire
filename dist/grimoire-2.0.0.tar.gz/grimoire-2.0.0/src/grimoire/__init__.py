"""
Grimoire - Technical documentation search tool
"""

from .config import GrimoireConfig
from .searcher import GrimoireSearcher, SearchMatch

__version__ = "2.0.0"